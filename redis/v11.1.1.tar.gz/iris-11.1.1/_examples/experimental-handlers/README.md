# Install iris-contrib/middleware

```sh
$ go get -u github.com/iris-contrib/middleware/...
```